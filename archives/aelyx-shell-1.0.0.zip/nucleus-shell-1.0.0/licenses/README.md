# Licenses

This repository contains code from other repositories. Files containing such code should include a license notice. I've updated the code and put copyrights in the borrowed code. Also read `THIRD_PARTY.md` to see from which repo were the code taken from.
