# This folder contains all the installation scripts:
* `pkg.sh`: Installs the complete shell with all required pacakges. (Arch-Based Only)
* `dots.sh`: Copy dotfiles on user selections.
* `unified.sh`: Complete installation at once.
* `update.sh`: Updates the shell to latest version.
