# This repository contains the some of the code from the following repositories:
* etherealboi/twinshell (GNU General Public License v3.0)
* end-4/dots-hyprland (GNU General Public License v3.0)
* bgibson72/yahr-quickshell (License not stated in the project root.)
* corecathx/whisker (GPL-3.0 License)
