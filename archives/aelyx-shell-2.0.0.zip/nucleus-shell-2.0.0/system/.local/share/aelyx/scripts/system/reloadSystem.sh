#!/bin/sh

killall quickshell
quickshell
hyprctl reload
